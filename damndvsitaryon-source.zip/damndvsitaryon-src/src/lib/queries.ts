import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Tables } from "@/integrations/supabase/types";

export type Booking = Tables<"bookings">;
export type Destination = Tables<"destinations">;

export const bookingsQuery = queryOptions({
  queryKey: ["bookings"],
  queryFn: async () => {
    const { data, error } = await supabase
      .from("bookings")
      .select("*")
      .order("visit_date", { ascending: false });
    if (error) throw error;
    return data as Booking[];
  },
});

export const destinationsQuery = queryOptions({
  queryKey: ["destinations"],
  queryFn: async () => {
    const { data, error } = await supabase
      .from("destinations")
      .select("*")
      .order("name", { ascending: true });
    if (error) throw error;
    return data as Destination[];
  },
});
