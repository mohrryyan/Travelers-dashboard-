import { Link, useRouterState } from "@tanstack/react-router";
import { useState, type ReactNode } from "react";
import { toast } from "sonner";
import {
  LayoutGrid, Users, CalendarCheck, MapPin, BarChart3, Settings, LifeBuoy,
  Bell, Menu, Download, ExternalLink,
} from "lucide-react";

const NAV = [
  { icon: LayoutGrid, label: "Dashboard", to: "/" },
  { icon: Users, label: "Visitors", to: "/visitors" },
  { icon: CalendarCheck, label: "Bookings", to: "/bookings" },
  { icon: MapPin, label: "Destinations", to: "/destinations" },
  { icon: BarChart3, label: "Reports", to: "/reports" },
] as const;

export function exportBookingsCsv(rows: { visitor_name: string; booking_ref: string; destination: string; visit_date: string; party_size: number; status: string }[]) {
  const fmt = (d: string) => new Intl.DateTimeFormat("en-IN", { day: "numeric", month: "short", year: "numeric" }).format(new Date(d + "T00:00:00"));
  const data = [["Visitor", "Booking ID", "Destination", "Visit date", "Visitors", "Status"],
    ...rows.map((b) => [b.visitor_name, b.booking_ref, b.destination, fmt(b.visit_date), String(b.party_size), b.status])];
  const csv = data.map((r) => r.map((v) => '"' + String(v).replace(/"/g, '""') + '"').join(",")).join("\r\n");
  const url = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8;" }));
  const a = document.createElement("a");
  a.href = url; a.download = "damndvsitaryon-visitors.csv"; a.click();
  URL.revokeObjectURL(url);
  toast.success("Visitor list exported");
}

export function DashboardLayout({ children, onExport }: { children: ReactNode; onExport?: () => void }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  return (
    <div className="grid min-h-screen lg:grid-cols-[240px_minmax(0,1fr)]">
      <aside className={`fixed inset-y-0 left-0 z-40 flex w-[260px] flex-col gap-7 border-r border-sidebar-border bg-sidebar p-6 transition-transform lg:static lg:translate-x-0 ${sidebarOpen ? "translate-x-0" : "-translate-x-full"}`}>
        <div className="flex items-center gap-3 px-2">
          <div className="grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-primary to-teal-700 font-black text-xl text-primary-foreground">D</div>
          <div>
            <strong className="block text-[15px] text-foreground">Damndvsitaryon</strong>
            <small className="text-[11px] text-muted-foreground">VISITOR MANAGEMENT</small>
          </div>
        </div>
        <div>
          <div className="mb-2 px-3 text-[10px] font-extrabold tracking-[1.5px] text-muted-foreground/70">WORKSPACE</div>
          <nav className="grid gap-1">
            {NAV.map((n) => {
              const active = pathname === n.to;
              return (
                <Link key={n.label} to={n.to} onClick={() => setSidebarOpen(false)}
                  className={`flex items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm transition-colors ${active ? "bg-sidebar-accent text-sidebar-primary" : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-primary"}`}>
                  <n.icon className="h-4 w-4" />{n.label}
                </Link>
              );
            })}
          </nav>
        </div>
        <div>
          <div className="mb-2 px-3 text-[10px] font-extrabold tracking-[1.5px] text-muted-foreground/70">PREFERENCES</div>
          <nav className="grid gap-1">
            <Link to="/settings" onClick={() => setSidebarOpen(false)} className={`flex items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm transition-colors ${pathname === "/settings" ? "bg-sidebar-accent text-sidebar-primary" : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-primary"}`}><Settings className="h-4 w-4" />Settings</Link>
            <Link to="/help" onClick={() => setSidebarOpen(false)} className={`flex items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm transition-colors ${pathname === "/help" ? "bg-sidebar-accent text-sidebar-primary" : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-primary"}`}><LifeBuoy className="h-4 w-4" />Help & support</Link>
          </nav>
        </div>
        <div className="mt-auto grid gap-3">
          <Link to="/book" className="flex items-center justify-center gap-2 rounded-lg bg-primary px-3 py-2.5 text-xs font-semibold text-primary-foreground transition-opacity hover:opacity-90">
            <ExternalLink className="h-3.5 w-3.5" /> Public booking form
          </Link>
          <div className="rounded-xl border border-sidebar-border bg-card p-4">
            <b className="text-xs text-foreground">Make every visit count</b>
            <p className="my-2 text-xs text-muted-foreground">Keep visitor information organised in one place.</p>
            <button onClick={onExport} className="flex w-full items-center justify-center gap-2 rounded-lg border border-primary/40 py-2 text-xs text-primary transition-colors hover:bg-primary/10">
              <Download className="h-3.5 w-3.5" /> Export visitor list
            </button>
          </div>
        </div>
      </aside>
      {sidebarOpen && <div className="fixed inset-0 z-30 bg-black/50 lg:hidden" onClick={() => setSidebarOpen(false)} />}

      <main className="min-w-0 px-4 py-6 sm:px-8 lg:px-10">
        <header className="mb-7 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <button className="grid h-9 w-9 place-items-center rounded-lg border border-border bg-card lg:hidden" onClick={() => setSidebarOpen(true)} aria-label="Open navigation"><Menu className="h-4 w-4" /></button>
            <div className="text-xs text-muted-foreground">Workspace / <span className="text-foreground">{NAV.find((n) => n.to === pathname)?.label ?? (pathname === "/settings" ? "Settings" : pathname === "/help" ? "Help & support" : "Dashboard")}</span></div>
          </div>
          <div className="flex items-center gap-3">
            <button className="relative grid h-9 w-9 place-items-center rounded-lg border border-border bg-card" onClick={() => toast.success("You're all caught up!")} aria-label="Notifications">
              <Bell className="h-4 w-4" /><span className="absolute right-2 top-2 h-1.5 w-1.5 rounded-full bg-warning" />
            </button>
            <div className="grid h-9 w-9 place-items-center rounded-full bg-accent text-sm font-extrabold text-primary">D</div>
          </div>
        </header>
        {children}
      </main>
    </div>
  );
}
