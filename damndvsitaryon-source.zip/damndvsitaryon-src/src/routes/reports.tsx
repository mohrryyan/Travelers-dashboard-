import { createFileRoute } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { useMemo } from "react";
import { BarChart3, CheckCircle2, Clock, XCircle, Users } from "lucide-react";
import { bookingsQuery, destinationsQuery } from "@/lib/queries";
import { DashboardLayout, exportBookingsCsv } from "@/components/DashboardLayout";

export const Route = createFileRoute("/reports")({
  loader: ({ context }) => Promise.all([
    context.queryClient.ensureQueryData(bookingsQuery),
    context.queryClient.ensureQueryData(destinationsQuery),
  ]),
  head: () => ({
    meta: [
      { title: "Reports — Damndvsitaryon" },
      { name: "description", content: "Booking trends, status breakdown and destination demand reports for Damndvsitaryon." },
      { property: "og:title", content: "Reports — Damndvsitaryon" },
      { property: "og:description", content: "Booking trends, status breakdown and destination demand reports for Damndvsitaryon." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ReportsPage,
});

function ReportsPage() {
  const { data: bookings } = useSuspenseQuery(bookingsQuery);
  const { data: destinations } = useSuspenseQuery(destinationsQuery);

  const byStatus = useMemo(() => ({
    confirmed: bookings.filter((b) => b.status === "confirmed"),
    pending: bookings.filter((b) => b.status === "pending"),
    cancelled: bookings.filter((b) => b.status === "cancelled"),
  }), [bookings]);

  const byDestination = useMemo(() =>
    destinations.map((d) => {
      const dBookings = bookings.filter((b) => b.destination === d.name && b.status !== "cancelled");
      return { name: d.name, bookings: dBookings.length, visitors: dBookings.reduce((s, b) => s + b.party_size, 0) };
    }).sort((a, b) => b.visitors - a.visitors),
  [bookings, destinations]);

  const maxVisitors = Math.max(1, ...byDestination.map((d) => d.visitors));
  const total = Math.max(1, bookings.length);

  const cards = [
    { icon: CheckCircle2, label: "Confirmed", value: byStatus.confirmed.length, pct: Math.round((byStatus.confirmed.length / total) * 100), cls: "text-primary" },
    { icon: Clock, label: "Pending", value: byStatus.pending.length, pct: Math.round((byStatus.pending.length / total) * 100), cls: "text-warning" },
    { icon: XCircle, label: "Cancelled", value: byStatus.cancelled.length, pct: Math.round((byStatus.cancelled.length / total) * 100), cls: "text-destructive" },
    { icon: Users, label: "Total visitors", value: bookings.reduce((s, b) => s + b.party_size, 0), pct: null as number | null, cls: "text-primary" },
  ];

  return (
    <DashboardLayout onExport={() => exportBookingsCsv(bookings)}>
      <div className="mb-6">
        <div className="text-[10px] font-extrabold uppercase tracking-[1.8px] text-primary">Insights</div>
        <h1 className="mt-1 text-3xl font-bold tracking-tight">Reports</h1>
        <p className="mt-1 text-sm text-muted-foreground">Booking trends and destination demand at a glance.</p>
      </div>

      <section className="mb-5 grid grid-cols-2 gap-4 xl:grid-cols-4">
        {cards.map((c) => (
          <article key={c.label} className="rounded-2xl border border-border bg-card p-5">
            <div className="flex items-center justify-between text-xs text-muted-foreground">
              {c.label}
              <c.icon className={`h-4 w-4 ${c.cls}`} />
            </div>
            <div className="mt-3 text-3xl font-bold tracking-tight">{c.value}</div>
            {c.pct !== null && <div className="mt-1 text-[11px] text-muted-foreground">{c.pct}% of all bookings</div>}
          </article>
        ))}
      </section>

      <section className="grid gap-4 xl:grid-cols-2">
        <article className="rounded-2xl border border-border bg-card p-5">
          <div className="mb-4 flex items-center gap-2">
            <BarChart3 className="h-4 w-4 text-primary" />
            <h2 className="text-[15px] font-semibold">Demand by destination</h2>
          </div>
          <div className="grid gap-4">
            {byDestination.map((d) => (
              <div key={d.name}>
                <div className="mb-1.5 flex justify-between text-xs">
                  <span className="font-medium">{d.name}</span>
                  <span className="text-muted-foreground">{d.visitors} visitors · {d.bookings} bookings</span>
                </div>
                <div className="h-2.5 overflow-hidden rounded-full bg-background">
                  <div className="h-full rounded-full bg-primary transition-all" style={{ width: Math.round((d.visitors / maxVisitors) * 100) + "%" }} />
                </div>
              </div>
            ))}
            {byDestination.length === 0 && <p className="text-sm text-muted-foreground">No destinations yet.</p>}
          </div>
        </article>

        <article className="rounded-2xl border border-border bg-card p-5">
          <div className="mb-4 flex items-center gap-2">
            <CheckCircle2 className="h-4 w-4 text-primary" />
            <h2 className="text-[15px] font-semibold">Status breakdown</h2>
          </div>
          <div className="flex h-4 overflow-hidden rounded-full bg-background">
            <div className="bg-primary" style={{ width: (byStatus.confirmed.length / total) * 100 + "%" }} />
            <div className="bg-warning" style={{ width: (byStatus.pending.length / total) * 100 + "%" }} />
            <div className="bg-destructive" style={{ width: (byStatus.cancelled.length / total) * 100 + "%" }} />
          </div>
          <div className="mt-4 grid gap-2 text-xs">
            <div className="flex items-center gap-2"><span className="h-2.5 w-2.5 rounded-full bg-primary" /> Confirmed — {byStatus.confirmed.length}</div>
            <div className="flex items-center gap-2"><span className="h-2.5 w-2.5 rounded-full bg-warning" /> Pending — {byStatus.pending.length}</div>
            <div className="flex items-center gap-2"><span className="h-2.5 w-2.5 rounded-full bg-destructive" /> Cancelled — {byStatus.cancelled.length}</div>
          </div>
          <div className="mt-5 rounded-xl border border-primary/30 bg-primary/10 p-3 text-[11px] text-foreground/90">
            <b className="mb-1 block text-primary">Reading this report</b>
            A high pending share means requests are waiting for your review — confirm them from the Bookings page.
          </div>
        </article>
      </section>
    </DashboardLayout>
  );
}
