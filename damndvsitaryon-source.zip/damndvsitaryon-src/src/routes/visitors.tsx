import { createFileRoute } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { Search, Users } from "lucide-react";
import { bookingsQuery } from "@/lib/queries";
import { DashboardLayout, exportBookingsCsv } from "@/components/DashboardLayout";
import { STATUS_STYLES, initials, fmtDate } from "./index";

export const Route = createFileRoute("/visitors")({
  loader: ({ context }) => context.queryClient.ensureQueryData(bookingsQuery),
  head: () => ({
    meta: [
      { title: "Visitors — Damndvsitaryon" },
      { name: "description", content: "Every visitor who has booked a visit to Damndvsitaryon, with their booking history." },
      { property: "og:title", content: "Visitors — Damndvsitaryon" },
      { property: "og:description", content: "Every visitor who has booked a visit to Damndvsitaryon, with their booking history." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: VisitorsPage,
});

function VisitorsPage() {
  const { data: bookings } = useSuspenseQuery(bookingsQuery);
  const [search, setSearch] = useState("");

  const visitors = useMemo(() => {
    const map = new Map<string, { name: string; bookings: number; visitors: number; lastVisit: string; statuses: string[] }>();
    for (const b of bookings) {
      const v = map.get(b.visitor_name) ?? { name: b.visitor_name, bookings: 0, visitors: 0, lastVisit: b.visit_date, statuses: [] };
      v.bookings += 1;
      v.visitors += b.party_size;
      if (b.visit_date > v.lastVisit) v.lastVisit = b.visit_date;
      v.statuses.push(b.status);
      map.set(b.visitor_name, v);
    }
    const q = search.toLowerCase();
    return [...map.values()].filter((v) => !q || v.name.toLowerCase().includes(q)).sort((a, b) => b.lastVisit.localeCompare(a.lastVisit));
  }, [bookings, search]);

  return (
    <DashboardLayout onExport={() => exportBookingsCsv(bookings)}>
      <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
        <div>
          <div className="text-[10px] font-extrabold uppercase tracking-[1.8px] text-primary">People</div>
          <h1 className="mt-1 text-3xl font-bold tracking-tight">Visitors</h1>
          <p className="mt-1 text-sm text-muted-foreground">{visitors.length} unique visitors across all bookings.</p>
        </div>
        <div className="relative w-full sm:w-64">
          <Search className="absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
          <input value={search} onChange={(e) => setSearch(e.target.value)} type="search" placeholder="Search visitors…" aria-label="Search visitors"
            className="w-full rounded-lg border border-input bg-card py-2 pl-9 pr-3 text-sm outline-none focus:border-primary" />
        </div>
      </div>

      <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {visitors.map((v) => {
          const latest = v.statuses[0] ?? "pending";
          return (
            <article key={v.name} className="rounded-2xl border border-border bg-card p-5">
              <div className="flex items-center gap-3">
                <div className="grid h-11 w-11 place-items-center rounded-xl bg-secondary text-sm font-extrabold text-primary">{initials(v.name)}</div>
                <div className="min-w-0">
                  <b className="block truncate text-sm">{v.name}</b>
                  <span className={`mt-1 inline-block rounded-full px-2.5 py-0.5 text-[10px] font-bold capitalize ${STATUS_STYLES[latest] ?? STATUS_STYLES["pending"]}`}>{latest}</span>
                </div>
                <Users className="ml-auto h-4 w-4 text-muted-foreground" />
              </div>
              <div className="mt-4 grid grid-cols-3 gap-2 text-center">
                <div className="rounded-lg bg-background/60 py-2"><b className="block text-base">{v.bookings}</b><small className="text-[10px] text-muted-foreground">Bookings</small></div>
                <div className="rounded-lg bg-background/60 py-2"><b className="block text-base">{v.visitors}</b><small className="text-[10px] text-muted-foreground">People</small></div>
                <div className="rounded-lg bg-background/60 py-2"><b className="block text-base">{fmtDate(v.lastVisit).split(" ").slice(0, 2).join(" ")}</b><small className="text-[10px] text-muted-foreground">Last visit</small></div>
              </div>
            </article>
          );
        })}
        {visitors.length === 0 && <p className="col-span-full rounded-2xl border border-border bg-card p-10 text-center text-sm text-muted-foreground">No visitors found.</p>}
      </section>
    </DashboardLayout>
  );
}
