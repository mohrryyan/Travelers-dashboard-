import { createFileRoute } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { LifeBuoy } from "lucide-react";
import { bookingsQuery } from "@/lib/queries";
import { DashboardLayout, exportBookingsCsv } from "@/components/DashboardLayout";

export const Route = createFileRoute("/help")({
  loader: ({ context }) => context.queryClient.ensureQueryData(bookingsQuery),
  head: () => ({
    meta: [
      { title: "Help & Support — Damndvsitaryon" },
      { name: "description", content: "How to use the Damndvsitaryon visitor dashboard — bookings, destinations, exports and the public booking form." },
      { property: "og:title", content: "Help & Support — Damndvsitaryon" },
      { property: "og:description", content: "How to use the Damndvsitaryon visitor dashboard — bookings, destinations, exports and the public booking form." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: HelpPage,
});

const FAQ = [
  { q: "How do I add a booking?", a: "Click \"New booking\" on the Dashboard, fill in the visitor's details, and save. It appears in the list instantly." },
  { q: "How do visitors book themselves?", a: "Share the public booking form link (find it in the sidebar or Settings). Their requests arrive as Pending — confirm them from the Bookings page." },
  { q: "How do I change a booking's status?", a: "On the Dashboard, click the status badge to cycle it. On the Bookings page, pick the status from the dropdown." },
  { q: "How do I export my data?", a: "Click \"Export visitor list\" in the sidebar, or use Settings → Export all bookings. You get a CSV file that opens in Excel." },
  { q: "Is my data saved?", a: "Yes — everything is stored in your cloud database and syncs across devices automatically." },
  { q: "How do I close a destination?", a: "On the Destinations page, click the Open/Closed badge on a destination card to toggle it." },
];

function HelpPage() {
  const { data: bookings } = useSuspenseQuery(bookingsQuery);

  return (
    <DashboardLayout onExport={() => exportBookingsCsv(bookings)}>
      <div className="mb-6">
        <div className="text-[10px] font-extrabold uppercase tracking-[1.8px] text-primary">Support</div>
        <h1 className="mt-1 text-3xl font-bold tracking-tight">Help & support</h1>
        <p className="mt-1 text-sm text-muted-foreground">Quick answers to common questions.</p>
      </div>

      <section className="grid max-w-2xl gap-3">
        {FAQ.map((f) => (
          <details key={f.q} className="group rounded-2xl border border-border bg-card p-5">
            <summary className="flex cursor-pointer list-none items-center gap-3 text-sm font-semibold">
              <LifeBuoy className="h-4 w-4 shrink-0 text-primary" />{f.q}
              <span className="ml-auto text-muted-foreground transition-transform group-open:rotate-45">+</span>
            </summary>
            <p className="mt-3 pl-7 text-xs leading-relaxed text-muted-foreground">{f.a}</p>
          </details>
        ))}
      </section>
    </DashboardLayout>
  );
}
