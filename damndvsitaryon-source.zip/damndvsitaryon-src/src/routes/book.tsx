import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { z } from "zod";
import { CalendarCheck, CheckCircle2, ArrowLeft } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/book")({
  head: () => ({
    meta: [
      { title: "Book a Visit — Damndvsitaryon" },
      { name: "description", content: "Request your visit to Damndvsitaryon — choose a destination, date and party size, and we'll confirm your booking." },
      { property: "og:title", content: "Book a Visit — Damndvsitaryon" },
      { property: "og:description", content: "Request your visit to Damndvsitaryon — choose a destination, date and party size, and we'll confirm your booking." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: BookPage,
});

const bookingSchema = z.object({
  visitor_name: z.string().trim().min(2, "Please enter your name").max(100, "Name must be under 100 characters"),
  destination: z.string().trim().min(1, "Please choose a destination"),
  visit_date: z.string().min(1, "Please pick a date").refine((d) => d >= new Date().toISOString().slice(0, 10), "Please pick a future date"),
  party_size: z.number().int().min(1, "At least 1 visitor").max(50, "Maximum 50 visitors per booking"),
});

const DESTINATIONS = ["Dam Viewpoint", "Nature Trail", "Bird Sanctuary", "Boating Point"];

function BookPage() {
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState<string | null>(null);

  const onSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const parsed = bookingSchema.safeParse({
      visitor_name: f.get("visitor_name"),
      destination: f.get("destination"),
      visit_date: f.get("visit_date"),
      party_size: Number(f.get("party_size")),
    });
    if (!parsed.success) {
      const errs: Record<string, string> = {};
      for (const issue of parsed.error.issues) errs[String(issue.path[0])] = issue.message;
      setErrors(errs);
      return;
    }
    setErrors({});
    setSubmitting(true);
    const ref = "BK-" + Math.floor(1000 + Math.random() * 9000);
    const { error } = await supabase.from("bookings").insert({ ...parsed.data, booking_ref: ref, status: "pending" });
    setSubmitting(false);
    if (error) {
      setErrors({ form: "Something went wrong — please try again." });
    } else {
      setDone(ref);
    }
  };

  const inputCls = "w-full rounded-lg border border-input bg-background px-3.5 py-2.5 text-sm text-foreground outline-none focus:border-primary";
  const labelCls = "grid gap-1.5 text-xs font-medium text-muted-foreground";

  return (
    <div className="flex min-h-screen flex-col items-center px-4 py-10 sm:py-16">
      <div className="w-full max-w-md">
        <Link to="/" className="mb-8 inline-flex items-center gap-2 text-xs text-muted-foreground transition-colors hover:text-primary">
          <ArrowLeft className="h-3.5 w-3.5" /> Back to dashboard
        </Link>

        <div className="mb-8 flex items-center gap-3">
          <div className="grid h-11 w-11 place-items-center rounded-xl bg-gradient-to-br from-primary to-teal-700 font-black text-xl text-primary-foreground">D</div>
          <div>
            <strong className="block text-base">Damndvsitaryon</strong>
            <small className="text-[11px] text-muted-foreground">BOOK YOUR VISIT</small>
          </div>
        </div>

        {done ? (
          <div className="rounded-2xl border border-primary/30 bg-card p-8 text-center">
            <CheckCircle2 className="mx-auto mb-4 h-12 w-12 text-primary" />
            <h1 className="text-xl font-bold">Request received!</h1>
            <p className="mt-2 text-sm text-muted-foreground">
              Your booking request <b className="text-foreground">{done}</b> has been submitted. We'll review it and confirm shortly.
            </p>
            <button onClick={() => setDone(null)} className="mt-6 rounded-lg border border-primary/40 px-5 py-2 text-sm text-primary transition-colors hover:bg-primary/10">
              Make another booking
            </button>
          </div>
        ) : (
          <form onSubmit={onSubmit} className="rounded-2xl border border-border bg-card p-6 sm:p-8">
            <div className="mb-6">
              <h1 className="flex items-center gap-2 text-xl font-bold"><CalendarCheck className="h-5 w-5 text-primary" /> Book a visit</h1>
              <p className="mt-1 text-sm text-muted-foreground">Fill in your details and we'll confirm your slot.</p>
            </div>
            <div className="grid gap-4">
              <label className={labelCls}>Your name
                <input name="visitor_name" maxLength={100} placeholder="e.g. Ananya Rao" className={inputCls} />
                {errors["visitor_name"] && <span className="text-[11px] text-destructive">{errors["visitor_name"]}</span>}
              </label>
              <label className={labelCls}>Destination
                <select name="destination" className={inputCls}>
                  {DESTINATIONS.map((d) => <option key={d}>{d}</option>)}
                </select>
              </label>
              <div className="grid grid-cols-2 gap-4">
                <label className={labelCls}>Visit date
                  <input type="date" name="visit_date" min={new Date().toISOString().slice(0, 10)} className={inputCls} />
                  {errors["visit_date"] && <span className="text-[11px] text-destructive">{errors["visit_date"]}</span>}
                </label>
                <label className={labelCls}>Visitors
                  <input type="number" name="party_size" min="1" max="50" defaultValue="2" className={inputCls} />
                  {errors["party_size"] && <span className="text-[11px] text-destructive">{errors["party_size"]}</span>}
                </label>
              </div>
              {errors["form"] && <p className="text-xs text-destructive">{errors["form"]}</p>}
              <button disabled={submitting} className="mt-2 rounded-lg bg-primary py-3 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90 disabled:opacity-50">
                {submitting ? "Submitting…" : "Submit booking request"}
              </button>
              <p className="text-center text-[11px] text-muted-foreground">Requests are reviewed before confirmation.</p>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
