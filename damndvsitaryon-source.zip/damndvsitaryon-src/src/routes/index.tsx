import { createFileRoute } from "@tanstack/react-router";
import { useSuspenseQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import {
  Users, CalendarCheck, Clock, CheckCircle2, Search, Sun, Sparkles,
  Trash2, X, Plus,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { bookingsQuery, destinationsQuery, type Booking } from "@/lib/queries";
import { DashboardLayout, exportBookingsCsv } from "@/components/DashboardLayout";

export const Route = createFileRoute("/")({
  loader: ({ context }) => Promise.all([
    context.queryClient.ensureQueryData(bookingsQuery),
    context.queryClient.ensureQueryData(destinationsQuery),
  ]),
  head: () => ({
    meta: [
      { title: "Damndvsitaryon — Visitor Dashboard" },
      { name: "description", content: "Manage visitor bookings, destinations and traffic for Damndvsitaryon in one live dashboard." },
      { property: "og:title", content: "Damndvsitaryon — Visitor Dashboard" },
      { property: "og:description", content: "Manage visitor bookings, destinations and traffic for Damndvsitaryon in one live dashboard." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Dashboard,
});

export const STATUS_STYLES: Record<string, string> = {
  confirmed: "bg-primary/15 text-primary",
  pending: "bg-warning/15 text-warning",
  cancelled: "bg-destructive/15 text-destructive",
};

export function initials(name: string) {
  return name.split(" ").map((p) => p[0]).slice(0, 2).join("").toUpperCase();
}

export function fmtDate(d: string) {
  return new Intl.DateTimeFormat("en-IN", { day: "numeric", month: "short", year: "numeric" }).format(new Date(d + "T00:00:00"));
}

function Dashboard() {
  const { data: bookings } = useSuspenseQuery(bookingsQuery);
  const { data: destinations } = useSuspenseQuery(destinationsQuery);
  const queryClient = useQueryClient();
  const [search, setSearch] = useState("");
  const [addOpen, setAddOpen] = useState(false);
  const [detail, setDetail] = useState<Booking | null>(null);

  const invalidate = () => queryClient.invalidateQueries({ queryKey: ["bookings"] });

  const addMutation = useMutation({
    mutationFn: async (b: { visitor_name: string; destination: string; visit_date: string; party_size: number; status: string }) => {
      const ref = "BK-" + Math.floor(1000 + Math.random() * 9000);
      const { error } = await supabase.from("bookings").insert({ ...b, booking_ref: ref });
      if (error) throw error;
    },
    onSuccess: () => { invalidate(); setAddOpen(false); toast.success("Booking added"); },
    onError: (e) => toast.error("Could not add booking: " + e.message),
  });

  const statusMutation = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      const { error } = await supabase.from("bookings").update({ status }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => { invalidate(); toast.success("Status updated"); },
    onError: (e) => toast.error("Update failed: " + e.message),
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("bookings").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => { invalidate(); setDetail(null); toast.success("Booking deleted"); },
    onError: (e) => toast.error("Delete failed: " + e.message),
  });

  const filtered = useMemo(() => {
    const q = search.toLowerCase();
    return bookings.filter((b) => !q || `${b.visitor_name} ${b.destination} ${b.booking_ref} ${b.status}`.toLowerCase().includes(q));
  }, [bookings, search]);

  const stats = useMemo(() => {
    const today = new Date().toISOString().slice(0, 10);
    const totalVisitors = bookings.reduce((s, b) => s + b.party_size, 0);
    const confirmed = bookings.filter((b) => b.status === "confirmed").length;
    const upcoming = bookings.filter((b) => b.visit_date >= today && b.status !== "cancelled").length;
    return { total: bookings.length, totalVisitors, confirmed, upcoming };
  }, [bookings]);

  const chart = useMemo(() => {
    const days: { label: string; value: number }[] = [];
    const now = new Date();
    for (let i = 6; i >= 0; i--) {
      const d = new Date(now); d.setDate(now.getDate() - i);
      const key = d.toISOString().slice(0, 10);
      const value = bookings.filter((b) => b.visit_date === key && b.status !== "cancelled").reduce((s, b) => s + b.party_size, 0);
      days.push({ label: d.toLocaleDateString("en-IN", { weekday: "short" }), value });
    }
    return days;
  }, [bookings]);

  const maxChart = Math.max(1, ...chart.map((d) => d.value));
  const xs = chart.map((_, i) => 42 + (i * (568 / Math.max(1, chart.length - 1))));
  const ys = chart.map((d) => 205 - (d.value / maxChart) * 180);
  const linePath = xs.map((x, i) => (i ? "L" : "M") + x.toFixed(0) + " " + (ys[i] ?? 205).toFixed(0)).join(" ");

  return (
    <DashboardLayout onExport={() => exportBookingsCsv(bookings)}>
      <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
        <div>
          <div className="text-[10px] font-extrabold uppercase tracking-[1.8px] text-primary">Overview</div>
          <h1 className="mt-1 text-3xl font-bold tracking-tight">Visitor Dashboard</h1>
          <p className="mt-1 text-sm text-muted-foreground">Live bookings from your database — add, update and export anytime.</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="rounded-lg border border-border bg-card px-3 py-2 text-xs text-muted-foreground">
            {new Intl.DateTimeFormat("en-IN", { day: "numeric", month: "short", year: "numeric" }).format(new Date())}
          </div>
          <button onClick={() => setAddOpen(true)} className="flex items-center gap-2 rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90">
            <Plus className="h-4 w-4" /> New booking
          </button>
        </div>
      </div>

      <section className="mb-5 grid grid-cols-2 gap-4 xl:grid-cols-4">
        {[
          { icon: CalendarCheck, label: "Total bookings", value: stats.total, sub: "all time" },
          { icon: Users, label: "Total visitors", value: stats.totalVisitors, sub: "across bookings" },
          { icon: CheckCircle2, label: "Confirmed", value: stats.confirmed, sub: "ready to visit" },
          { icon: Clock, label: "Upcoming visits", value: stats.upcoming, sub: "from today" },
        ].map((s) => (
          <article key={s.label} className="rounded-2xl border border-border bg-card p-5">
            <div className="flex items-center justify-between text-xs text-muted-foreground">
              {s.label}
              <span className="grid h-8 w-8 place-items-center rounded-lg bg-accent text-primary"><s.icon className="h-4 w-4" /></span>
            </div>
            <div className="mt-3 text-3xl font-bold tracking-tight">{s.value}</div>
            <div className="mt-1 text-[11px] text-primary">{s.sub}</div>
          </article>
        ))}
      </section>

      <section className="mb-5 grid gap-4 xl:grid-cols-[minmax(0,1.7fr)_minmax(245px,1fr)]">
        <article className="rounded-2xl border border-border bg-card p-5">
          <div className="mb-4">
            <h2 className="text-[15px] font-semibold">Visitor traffic</h2>
            <p className="text-[11px] text-muted-foreground">Booked visitors over the last 7 days</p>
          </div>
          <svg className="block h-[210px] w-full" viewBox="0 0 620 230" preserveAspectRatio="none" role="img" aria-label="Visitor traffic chart">
            <defs>
              <linearGradient id="area" x1="0" x2="0" y1="0" y2="1">
                <stop offset="0%" stopColor="var(--primary)" stopOpacity=".25" />
                <stop offset="100%" stopColor="var(--primary)" stopOpacity="0" />
              </linearGradient>
            </defs>
            {[25, 70, 115, 160, 205].map((y) => <line key={y} x1="42" y1={y} x2="610" y2={y} stroke="var(--border)" strokeDasharray="3 5" />)}
            <path d={`${linePath} L610 205 L42 205 Z`} fill="url(#area)" />
            <path d={linePath} fill="none" stroke="var(--primary)" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
            {xs.map((x, i) => <circle key={i} cx={x} cy={ys[i] ?? 205} r="4" fill="var(--card)" stroke="var(--primary)" strokeWidth="2" />)}
            {chart.map((d, i) => <text key={i} x={xs[i]} y="225" textAnchor="middle" fill="var(--muted-foreground)" fontSize="10">{d.label}</text>)}
          </svg>
        </article>

        <article className="rounded-2xl border border-border bg-card p-5">
          <div className="mb-2 flex items-start justify-between">
            <div>
              <h2 className="text-[15px] font-semibold">At a glance</h2>
              <p className="text-[11px] text-muted-foreground">Helpful destination information</p>
            </div>
            <span className="grid h-8 w-8 place-items-center rounded-lg bg-accent text-primary"><Sparkles className="h-4 w-4" /></span>
          </div>
          {[
            { icon: Sun, title: "Weather today", sub: "Clear skies · Good for a visit", right: "28°", small: "Illustrative" },
            { icon: Clock, title: "Peak visiting hours", sub: "Plan staffing for busy periods", right: "10–1", small: "AM · PM" },
            { icon: CheckCircle2, title: "Booking status", sub: "Share of confirmed bookings", right: stats.total ? Math.round((stats.confirmed / stats.total) * 100) + "%" : "—", small: "Confirmed" },
          ].map((r) => (
            <div key={r.title} className="flex items-center gap-3 border-b border-border py-3 last:border-0">
              <div className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-secondary text-primary"><r.icon className="h-5 w-5" /></div>
              <div><b className="text-xs">{r.title}</b><p className="mt-0.5 text-[11px] text-muted-foreground">{r.sub}</p></div>
              <div className="ml-auto text-right"><strong className="text-base">{r.right}</strong><small className="block text-[10px] text-muted-foreground">{r.small}</small></div>
            </div>
          ))}
          <div className="mt-3 rounded-xl border border-primary/30 bg-primary/10 p-3 text-[11px] text-foreground/90">
            <b className="mb-1 block text-primary">Quick tip</b>
            Keep entry points clearly marked during peak hours to make arrivals smoother.
          </div>
        </article>
      </section>

      <section className="overflow-hidden rounded-2xl border border-border bg-card">
        <div className="flex flex-wrap items-center justify-between gap-3 p-5">
          <div>
            <h2 className="text-[15px] font-semibold">Recent visitor bookings</h2>
            <p className="text-[11px] text-muted-foreground">Live records · Search or export the list</p>
          </div>
          <div className="relative w-full sm:w-56">
            <Search className="absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
            <input value={search} onChange={(e) => setSearch(e.target.value)} type="search" placeholder="Search visitors or destination…" aria-label="Search visitor bookings"
              className="w-full rounded-lg border border-input bg-background py-2 pl-9 pr-3 text-sm outline-none focus:border-primary" />
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full border-collapse whitespace-nowrap">
            <thead>
              <tr className="bg-background/60 text-left text-[10px] uppercase tracking-wider text-muted-foreground">
                <th className="px-5 py-3">Visitor</th><th className="px-5 py-3">Destination</th><th className="px-5 py-3">Visit date</th><th className="px-5 py-3">Visitors</th><th className="px-5 py-3">Status</th><th className="px-5 py-3">Action</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((b) => (
                <tr key={b.id} className="border-t border-border text-xs transition-colors hover:bg-accent/40">
                  <td className="px-5 py-3.5">
                    <div className="flex items-center gap-2.5">
                      <div className="grid h-8 w-8 place-items-center rounded-lg bg-secondary text-[11px] font-extrabold text-primary">{initials(b.visitor_name)}</div>
                      <div><b>{b.visitor_name}</b><small className="block text-[10px] text-muted-foreground">{b.booking_ref}</small></div>
                    </div>
                  </td>
                  <td className="px-5 py-3.5">{b.destination}</td>
                  <td className="px-5 py-3.5">{fmtDate(b.visit_date)}</td>
                  <td className="px-5 py-3.5">{b.party_size}</td>
                  <td className="px-5 py-3.5">
                    <button onClick={() => statusMutation.mutate({ id: b.id, status: b.status === "confirmed" ? "pending" : b.status === "pending" ? "cancelled" : "confirmed" })}
                      title="Click to change status"
                      className={`inline-block rounded-full px-2.5 py-1 text-[10px] font-bold capitalize ${STATUS_STYLES[b.status] ?? STATUS_STYLES["pending"]}`}>
                      {b.status}
                    </button>
                  </td>
                  <td className="px-5 py-3.5">
                    <button onClick={() => setDetail(b)} className="text-[11px] text-primary hover:underline">View details ↗</button>
                  </td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr><td colSpan={6} className="px-5 py-10 text-center text-sm text-muted-foreground">No bookings match your search.</td></tr>
              )}
            </tbody>
          </table>
        </div>
        <div className="flex flex-wrap justify-between gap-2 px-5 py-3 text-[11px] text-muted-foreground">
          <span>Showing {filtered.length} of {bookings.length} bookings</span>
          <span>Live data · Stored in your cloud database</span>
        </div>
      </section>

      {addOpen && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-black/60 p-4" onClick={() => setAddOpen(false)}>
          <form className="w-full max-w-md rounded-2xl border border-border bg-card p-6" onClick={(e) => e.stopPropagation()}
            onSubmit={(e) => {
              e.preventDefault();
              const f = new FormData(e.currentTarget);
              addMutation.mutate({
                visitor_name: String(f.get("visitor_name")),
                destination: String(f.get("destination")),
                visit_date: String(f.get("visit_date")),
                party_size: Number(f.get("party_size")) || 1,
                status: String(f.get("status")),
              });
            }}>
            <div className="mb-5 flex items-center justify-between">
              <h2 className="text-lg font-semibold">New booking</h2>
              <button type="button" onClick={() => setAddOpen(false)} aria-label="Close"><X className="h-4 w-4 text-muted-foreground" /></button>
            </div>
            <div className="grid gap-4">
              <label className="grid gap-1.5 text-xs text-muted-foreground">Visitor name
                <input required name="visitor_name" maxLength={100} className="rounded-lg border border-input bg-background px-3 py-2 text-sm text-foreground outline-none focus:border-primary" placeholder="e.g. Ananya Rao" />
              </label>
              <label className="grid gap-1.5 text-xs text-muted-foreground">Destination
                <select name="destination" className="rounded-lg border border-input bg-background px-3 py-2 text-sm text-foreground outline-none focus:border-primary">
                  {destinations.map((d) => <option key={d.id}>{d.name}</option>)}
                </select>
              </label>
              <div className="grid grid-cols-2 gap-4">
                <label className="grid gap-1.5 text-xs text-muted-foreground">Visit date
                  <input required type="date" name="visit_date" className="rounded-lg border border-input bg-background px-3 py-2 text-sm text-foreground outline-none focus:border-primary" />
                </label>
                <label className="grid gap-1.5 text-xs text-muted-foreground">Visitors
                  <input required type="number" min="1" max="50" defaultValue="2" name="party_size" className="rounded-lg border border-input bg-background px-3 py-2 text-sm text-foreground outline-none focus:border-primary" />
                </label>
              </div>
              <label className="grid gap-1.5 text-xs text-muted-foreground">Status
                <select name="status" className="rounded-lg border border-input bg-background px-3 py-2 text-sm text-foreground outline-none focus:border-primary">
                  <option value="confirmed">Confirmed</option><option value="pending">Pending</option><option value="cancelled">Cancelled</option>
                </select>
              </label>
              <button disabled={addMutation.isPending} className="mt-1 rounded-lg bg-primary py-2.5 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90 disabled:opacity-50">
                {addMutation.isPending ? "Saving…" : "Add booking"}
              </button>
            </div>
          </form>
        </div>
      )}

      {detail && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-black/60 p-4" onClick={() => setDetail(null)}>
          <div className="w-full max-w-sm rounded-2xl border border-border bg-card p-6" onClick={(e) => e.stopPropagation()}>
            <div className="mb-4 flex items-center justify-between">
              <h2 className="text-lg font-semibold">Booking {detail.booking_ref}</h2>
              <button onClick={() => setDetail(null)} aria-label="Close"><X className="h-4 w-4 text-muted-foreground" /></button>
            </div>
            <dl className="grid gap-3 text-sm">
              <div className="flex justify-between"><dt className="text-muted-foreground">Visitor</dt><dd className="font-medium">{detail.visitor_name}</dd></div>
              <div className="flex justify-between"><dt className="text-muted-foreground">Destination</dt><dd className="font-medium">{detail.destination}</dd></div>
              <div className="flex justify-between"><dt className="text-muted-foreground">Visit date</dt><dd className="font-medium">{fmtDate(detail.visit_date)}</dd></div>
              <div className="flex justify-between"><dt className="text-muted-foreground">Party size</dt><dd className="font-medium">{detail.party_size}</dd></div>
              <div className="flex justify-between"><dt className="text-muted-foreground">Status</dt><dd><span className={`rounded-full px-2.5 py-1 text-[10px] font-bold capitalize ${STATUS_STYLES[detail.status] ?? STATUS_STYLES["pending"]}`}>{detail.status}</span></dd></div>
            </dl>
            <button onClick={() => deleteMutation.mutate(detail.id)} disabled={deleteMutation.isPending}
              className="mt-6 flex w-full items-center justify-center gap-2 rounded-lg border border-destructive/40 py-2 text-sm text-destructive transition-colors hover:bg-destructive/10 disabled:opacity-50">
              <Trash2 className="h-4 w-4" /> Delete booking
            </button>
          </div>
        </div>
      )}
    </DashboardLayout>
  );
}
