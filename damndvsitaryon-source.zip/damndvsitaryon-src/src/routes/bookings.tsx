import { createFileRoute } from "@tanstack/react-router";
import { useSuspenseQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { Search, Trash2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { bookingsQuery } from "@/lib/queries";
import { DashboardLayout, exportBookingsCsv } from "@/components/DashboardLayout";
import { STATUS_STYLES, initials, fmtDate } from "./index";

export const Route = createFileRoute("/bookings")({
  loader: ({ context }) => context.queryClient.ensureQueryData(bookingsQuery),
  head: () => ({
    meta: [
      { title: "Bookings — Damndvsitaryon" },
      { name: "description", content: "All visitor bookings for Damndvsitaryon — filter, confirm, cancel or remove records." },
      { property: "og:title", content: "Bookings — Damndvsitaryon" },
      { property: "og:description", content: "All visitor bookings for Damndvsitaryon — filter, confirm, cancel or remove records." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: BookingsPage,
});

const FILTERS = ["all", "confirmed", "pending", "cancelled"] as const;

function BookingsPage() {
  const { data: bookings } = useSuspenseQuery(bookingsQuery);
  const queryClient = useQueryClient();
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState<(typeof FILTERS)[number]>("all");

  const invalidate = () => queryClient.invalidateQueries({ queryKey: ["bookings"] });

  const statusMutation = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      const { error } = await supabase.from("bookings").update({ status }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => { invalidate(); toast.success("Status updated"); },
    onError: (e) => toast.error("Update failed: " + e.message),
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("bookings").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => { invalidate(); toast.success("Booking deleted"); },
    onError: (e) => toast.error("Delete failed: " + e.message),
  });

  const filtered = useMemo(() => {
    const q = search.toLowerCase();
    return bookings.filter((b) =>
      (filter === "all" || b.status === filter) &&
      (!q || `${b.visitor_name} ${b.destination} ${b.booking_ref}`.toLowerCase().includes(q)));
  }, [bookings, search, filter]);

  return (
    <DashboardLayout onExport={() => exportBookingsCsv(bookings)}>
      <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
        <div>
          <div className="text-[10px] font-extrabold uppercase tracking-[1.8px] text-primary">Records</div>
          <h1 className="mt-1 text-3xl font-bold tracking-tight">Bookings</h1>
          <p className="mt-1 text-sm text-muted-foreground">Filter by status, confirm requests, or remove records.</p>
        </div>
        <div className="relative w-full sm:w-64">
          <Search className="absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
          <input value={search} onChange={(e) => setSearch(e.target.value)} type="search" placeholder="Search bookings…" aria-label="Search bookings"
            className="w-full rounded-lg border border-input bg-card py-2 pl-9 pr-3 text-sm outline-none focus:border-primary" />
        </div>
      </div>

      <div className="mb-4 flex flex-wrap gap-2">
        {FILTERS.map((f) => (
          <button key={f} onClick={() => setFilter(f)}
            className={`rounded-full px-4 py-1.5 text-xs font-semibold capitalize transition-colors ${filter === f ? "bg-primary text-primary-foreground" : "border border-border bg-card text-muted-foreground hover:text-foreground"}`}>
            {f} {f !== "all" && `(${bookings.filter((b) => b.status === f).length})`}
          </button>
        ))}
      </div>

      <section className="overflow-hidden rounded-2xl border border-border bg-card">
        <div className="overflow-x-auto">
          <table className="w-full border-collapse whitespace-nowrap">
            <thead>
              <tr className="bg-background/60 text-left text-[10px] uppercase tracking-wider text-muted-foreground">
                <th className="px-5 py-3">Visitor</th><th className="px-5 py-3">Destination</th><th className="px-5 py-3">Visit date</th><th className="px-5 py-3">Visitors</th><th className="px-5 py-3">Status</th><th className="px-5 py-3">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((b) => (
                <tr key={b.id} className="border-t border-border text-xs transition-colors hover:bg-accent/40">
                  <td className="px-5 py-3.5">
                    <div className="flex items-center gap-2.5">
                      <div className="grid h-8 w-8 place-items-center rounded-lg bg-secondary text-[11px] font-extrabold text-primary">{initials(b.visitor_name)}</div>
                      <div><b>{b.visitor_name}</b><small className="block text-[10px] text-muted-foreground">{b.booking_ref}</small></div>
                    </div>
                  </td>
                  <td className="px-5 py-3.5">{b.destination}</td>
                  <td className="px-5 py-3.5">{fmtDate(b.visit_date)}</td>
                  <td className="px-5 py-3.5">{b.party_size}</td>
                  <td className="px-5 py-3.5">
                    <select value={b.status} onChange={(e) => statusMutation.mutate({ id: b.id, status: e.target.value })}
                      className={`rounded-full border-0 px-2.5 py-1 text-[10px] font-bold capitalize outline-none ${STATUS_STYLES[b.status] ?? STATUS_STYLES["pending"]}`}>
                      <option value="confirmed">confirmed</option><option value="pending">pending</option><option value="cancelled">cancelled</option>
                    </select>
                  </td>
                  <td className="px-5 py-3.5">
                    <button onClick={() => deleteMutation.mutate(b.id)} aria-label={`Delete booking ${b.booking_ref}`} className="text-muted-foreground transition-colors hover:text-destructive">
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr><td colSpan={6} className="px-5 py-10 text-center text-sm text-muted-foreground">No bookings match.</td></tr>
              )}
            </tbody>
          </table>
        </div>
        <div className="px-5 py-3 text-[11px] text-muted-foreground">Showing {filtered.length} of {bookings.length} bookings</div>
      </section>
    </DashboardLayout>
  );
}
