import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { Download, ExternalLink, Database, ShieldCheck } from "lucide-react";
import { bookingsQuery } from "@/lib/queries";
import { DashboardLayout, exportBookingsCsv } from "@/components/DashboardLayout";

export const Route = createFileRoute("/settings")({
  loader: ({ context }) => context.queryClient.ensureQueryData(bookingsQuery),
  head: () => ({
    meta: [
      { title: "Settings — Damndvsitaryon" },
      { name: "description", content: "Data, export and booking form settings for the Damndvsitaryon visitor dashboard." },
      { property: "og:title", content: "Settings — Damndvsitaryon" },
      { property: "og:description", content: "Data, export and booking form settings for the Damndvsitaryon visitor dashboard." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: SettingsPage,
});

function SettingsPage() {
  const { data: bookings } = useSuspenseQuery(bookingsQuery);

  return (
    <DashboardLayout onExport={() => exportBookingsCsv(bookings)}>
      <div className="mb-6">
        <div className="text-[10px] font-extrabold uppercase tracking-[1.8px] text-primary">Preferences</div>
        <h1 className="mt-1 text-3xl font-bold tracking-tight">Settings</h1>
        <p className="mt-1 text-sm text-muted-foreground">Data and booking form options.</p>
      </div>

      <section className="grid max-w-2xl gap-4">
        <article className="rounded-2xl border border-border bg-card p-5">
          <div className="flex items-center gap-2"><Database className="h-4 w-4 text-primary" /><h2 className="text-[15px] font-semibold">Your data</h2></div>
          <p className="mt-1 text-xs text-muted-foreground">{bookings.length} bookings are stored safely in your cloud database and sync across every device.</p>
          <button onClick={() => exportBookingsCsv(bookings)} className="mt-4 flex items-center gap-2 rounded-lg border border-primary/40 px-4 py-2 text-xs text-primary transition-colors hover:bg-primary/10">
            <Download className="h-3.5 w-3.5" /> Export all bookings (CSV)
          </button>
        </article>

        <article className="rounded-2xl border border-border bg-card p-5">
          <div className="flex items-center gap-2"><ExternalLink className="h-4 w-4 text-primary" /><h2 className="text-[15px] font-semibold">Public booking form</h2></div>
          <p className="mt-1 text-xs text-muted-foreground">Share this link with visitors so they can request bookings themselves. New requests arrive as <b className="text-foreground">Pending</b>.</p>
          <Link to="/book" className="mt-4 inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2 text-xs font-semibold text-primary-foreground transition-opacity hover:opacity-90">
            Open booking form ↗
          </Link>
        </article>

        <article className="rounded-2xl border border-border bg-card p-5">
          <div className="flex items-center gap-2"><ShieldCheck className="h-4 w-4 text-primary" /><h2 className="text-[15px] font-semibold">Access</h2></div>
          <p className="mt-1 text-xs text-muted-foreground">This dashboard is currently open to anyone with the link. If you'd like it protected with a login, just ask and I'll add sign-in.</p>
        </article>
      </section>
    </DashboardLayout>
  );
}
