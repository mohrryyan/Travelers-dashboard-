import { createFileRoute } from "@tanstack/react-router";
import { useSuspenseQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { MapPin, Plus, Users, X, Trash2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { bookingsQuery, destinationsQuery } from "@/lib/queries";
import { DashboardLayout, exportBookingsCsv } from "@/components/DashboardLayout";

export const Route = createFileRoute("/destinations")({
  loader: ({ context }) => Promise.all([
    context.queryClient.ensureQueryData(bookingsQuery),
    context.queryClient.ensureQueryData(destinationsQuery),
  ]),
  head: () => ({
    meta: [
      { title: "Destinations — Damndvsitaryon" },
      { name: "description", content: "Manage Damndvsitaryon destinations — capacity, opening status and booking demand." },
      { property: "og:title", content: "Destinations — Damndvsitaryon" },
      { property: "og:description", content: "Manage Damndvsitaryon destinations — capacity, opening status and booking demand." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: DestinationsPage,
});

function DestinationsPage() {
  const { data: bookings } = useSuspenseQuery(bookingsQuery);
  const { data: destinations } = useSuspenseQuery(destinationsQuery);
  const queryClient = useQueryClient();
  const [addOpen, setAddOpen] = useState(false);

  const invalidate = () => queryClient.invalidateQueries({ queryKey: ["destinations"] });

  const addMutation = useMutation({
    mutationFn: async (d: { name: string; description: string; capacity: number }) => {
      const { error } = await supabase.from("destinations").insert(d);
      if (error) throw error;
    },
    onSuccess: () => { invalidate(); setAddOpen(false); toast.success("Destination added"); },
    onError: (e) => toast.error("Could not add destination: " + e.message),
  });

  const toggleMutation = useMutation({
    mutationFn: async ({ id, is_open }: { id: string; is_open: boolean }) => {
      const { error } = await supabase.from("destinations").update({ is_open }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => { invalidate(); toast.success("Destination updated"); },
    onError: (e) => toast.error("Update failed: " + e.message),
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("destinations").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => { invalidate(); toast.success("Destination removed"); },
    onError: (e) => toast.error("Delete failed: " + e.message),
  });

  return (
    <DashboardLayout onExport={() => exportBookingsCsv(bookings)}>
      <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
        <div>
          <div className="text-[10px] font-extrabold uppercase tracking-[1.8px] text-primary">Places</div>
          <h1 className="mt-1 text-3xl font-bold tracking-tight">Destinations</h1>
          <p className="mt-1 text-sm text-muted-foreground">Capacity, opening status and booking demand per destination.</p>
        </div>
        <button onClick={() => setAddOpen(true)} className="flex items-center gap-2 rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90">
          <Plus className="h-4 w-4" /> New destination
        </button>
      </div>

      <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-2">
        {destinations.map((d) => {
          const dBookings = bookings.filter((b) => b.destination === d.name && b.status !== "cancelled");
          const demand = dBookings.reduce((s, b) => s + b.party_size, 0);
          const pct = Math.min(100, Math.round((demand / Math.max(1, d.capacity)) * 100));
          return (
            <article key={d.id} className="rounded-2xl border border-border bg-card p-5">
              <div className="flex items-start gap-3">
                <div className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-secondary text-primary"><MapPin className="h-5 w-5" /></div>
                <div className="min-w-0">
                  <b className="block text-sm">{d.name}</b>
                  <p className="mt-0.5 text-xs text-muted-foreground">{d.description}</p>
                </div>
                <button onClick={() => toggleMutation.mutate({ id: d.id, is_open: !d.is_open })}
                  className={`ml-auto shrink-0 rounded-full px-2.5 py-1 text-[10px] font-bold ${d.is_open ? "bg-primary/15 text-primary" : "bg-destructive/15 text-destructive"}`}>
                  {d.is_open ? "Open" : "Closed"}
                </button>
              </div>
              <div className="mt-4">
                <div className="mb-1.5 flex justify-between text-[11px] text-muted-foreground">
                  <span className="flex items-center gap-1"><Users className="h-3 w-3" /> {demand} booked</span>
                  <span>Capacity {d.capacity}</span>
                </div>
                <div className="h-2 overflow-hidden rounded-full bg-background">
                  <div className="h-full rounded-full bg-primary transition-all" style={{ width: pct + "%" }} />
                </div>
              </div>
              <div className="mt-4 flex items-center justify-between text-[11px] text-muted-foreground">
                <span>{dBookings.length} active bookings</span>
                <button onClick={() => deleteMutation.mutate(d.id)} aria-label={`Delete ${d.name}`} className="flex items-center gap-1 transition-colors hover:text-destructive">
                  <Trash2 className="h-3.5 w-3.5" /> Remove
                </button>
              </div>
            </article>
          );
        })}
      </section>

      {addOpen && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-black/60 p-4" onClick={() => setAddOpen(false)}>
          <form className="w-full max-w-md rounded-2xl border border-border bg-card p-6" onClick={(e) => e.stopPropagation()}
            onSubmit={(e) => {
              e.preventDefault();
              const f = new FormData(e.currentTarget);
              addMutation.mutate({
                name: String(f.get("name")),
                description: String(f.get("description") ?? ""),
                capacity: Number(f.get("capacity")) || 50,
              });
            }}>
            <div className="mb-5 flex items-center justify-between">
              <h2 className="text-lg font-semibold">New destination</h2>
              <button type="button" onClick={() => setAddOpen(false)} aria-label="Close"><X className="h-4 w-4 text-muted-foreground" /></button>
            </div>
            <div className="grid gap-4">
              <label className="grid gap-1.5 text-xs text-muted-foreground">Name
                <input required name="name" maxLength={80} className="rounded-lg border border-input bg-background px-3 py-2 text-sm text-foreground outline-none focus:border-primary" placeholder="e.g. Sunset Point" />
              </label>
              <label className="grid gap-1.5 text-xs text-muted-foreground">Description
                <textarea name="description" maxLength={300} rows={3} className="rounded-lg border border-input bg-background px-3 py-2 text-sm text-foreground outline-none focus:border-primary" placeholder="Short description for visitors" />
              </label>
              <label className="grid gap-1.5 text-xs text-muted-foreground">Daily capacity
                <input required type="number" min="1" max="10000" defaultValue="50" name="capacity" className="rounded-lg border border-input bg-background px-3 py-2 text-sm text-foreground outline-none focus:border-primary" />
              </label>
              <button disabled={addMutation.isPending} className="mt-1 rounded-lg bg-primary py-2.5 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90 disabled:opacity-50">
                {addMutation.isPending ? "Saving…" : "Add destination"}
              </button>
            </div>
          </form>
        </div>
      )}
    </DashboardLayout>
  );
}
