# Roadmap

- [x] Live dashboard with bookings database
- [ ] Public booking form at /book (visitors submit requests → pending)
- [ ] Link booking form from dashboard
- [ ] Build out all sidebar sections: Visitors, Bookings, Destinations, Reports, Settings, Help ("Also and everything")
- [ ] Verify build + end-to-end test
