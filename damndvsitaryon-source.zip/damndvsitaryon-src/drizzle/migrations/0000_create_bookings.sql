CREATE TABLE public.bookings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_ref TEXT NOT NULL UNIQUE,
  visitor_name TEXT NOT NULL,
  destination TEXT NOT NULL,
  visit_date DATE NOT NULL,
  party_size INTEGER NOT NULL DEFAULT 1,
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.bookings TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.bookings TO authenticated;
GRANT ALL ON public.bookings TO service_role;

ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read bookings" ON public.bookings FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Anyone can create bookings" ON public.bookings FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Anyone can update bookings" ON public.bookings FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Anyone can delete bookings" ON public.bookings FOR DELETE TO anon, authenticated USING (true);

INSERT INTO public.bookings (booking_ref, visitor_name, destination, visit_date, party_size, status) VALUES
  ('BK-1048', 'Arjun Sharma', 'Dam Viewpoint', '2026-10-18', 3, 'confirmed'),
  ('BK-1047', 'Priya Menon', 'Nature Trail', '2026-10-18', 2, 'pending'),
  ('BK-1046', 'Rahul Kumar', 'Bird Sanctuary', '2026-10-19', 4, 'confirmed'),
  ('BK-1045', 'Neha Fernandes', 'Dam Viewpoint', '2026-10-20', 2, 'cancelled'),
  ('BK-1044', 'Vikram K.', 'Nature Trail', '2026-10-21', 5, 'confirmed');