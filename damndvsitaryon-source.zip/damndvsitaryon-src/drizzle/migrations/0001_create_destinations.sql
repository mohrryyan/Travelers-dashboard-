CREATE TABLE public.destinations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  description TEXT NOT NULL DEFAULT '',
  capacity INTEGER NOT NULL DEFAULT 50,
  is_open BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.destinations TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.destinations TO authenticated;
GRANT ALL ON public.destinations TO service_role;

ALTER TABLE public.destinations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read destinations" ON public.destinations FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Anyone can create destinations" ON public.destinations FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Anyone can update destinations" ON public.destinations FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Anyone can delete destinations" ON public.destinations FOR DELETE TO anon, authenticated USING (true);

INSERT INTO public.destinations (name, description, capacity) VALUES
  ('Dam Viewpoint', 'Panoramic views over the reservoir and surrounding hills.', 120),
  ('Nature Trail', 'Guided 3 km walk through forest with interpretation boards.', 60),
  ('Bird Sanctuary', 'Wetland hides and watchtowers for migratory bird watching.', 40),
  ('Boating Point', 'Pedal and row boat rentals on the calm upper lake.', 80);